<template>
	<div class="cn-table-container" data-testid="cn-object-list" :class="{ 'cn-table-container--scrollable': scrollable }">
		<!-- Loading State -->
		<div v-if="loading" class="cn-table-loading" data-testid="cn-object-list-loading">
			<NcLoadingIcon :size="32" />
			<p>{{ loadingText }}</p>
		</div>

		<!-- Table -->
		<table v-else class="cn-data-table" data-testid="cn-object-list-table">
			<thead>
				<tr>
					<!-- Checkbox column -->
					<th v-if="selectable" class="cn-table-col--checkbox">
						<NcCheckboxRadioSwitch
							:checked="allSelected"
							:indeterminate="someSelected && !allSelected"
							@update:checked="toggleSelectAll" />
					</th>

					<!-- Data columns -->
					<th
						v-for="col in effectiveColumns"
						:key="col.key"
						:class="[
							col.sortable ? 'cn-table-header--sortable' : '',
							col.class || '',
						]"
						:style="col.width ? { width: col.width } : {}"
						@click="col.sortable ? onSort(col.key) : null">
						{{ col.label }}
						<span
							v-if="col.sortable && sortKey === col.key"
							class="cn-table-sort-indicator">
							{{ sortOrder === 'asc' ? '▲' : '▼' }}
						</span>
					</th>

					<!-- Actions column -->
					<th v-if="$scopedSlots['row-actions']" class="cn-table-col--actions">
						<slot name="actions-header" />
					</th>
				</tr>
			</thead>

			<tbody>
				<!-- Empty state -->
				<tr v-if="rows.length === 0" class="cn-table-empty" data-testid="cn-object-list-empty">
					<td :colspan="totalColumns">
						<slot name="empty">
							{{ emptyText }}
						</slot>
					</td>
				</tr>

				<!-- Data rows -->
				<tr
					v-for="row in rows"
					v-else
					:key="row[rowKey]"
					class="cn-table-row"
					data-testid="cn-object-row"
					:data-testid-row-id="row[rowKey]"
					:class="[
						isSelected(row) ? 'cn-table-row--selected' : '',
						rowClass ? rowClass(row) : '',
					]"
					@click="$emit('row-click', row)"
					@contextmenu.prevent="$emit('row-context-menu', { row, event: $event })">
					<!-- Checkbox -->
					<td v-if="selectable" class="cn-table-col--checkbox" @click.stop>
						<NcCheckboxRadioSwitch
							:checked="isSelected(row)"
							@update:checked="toggleSelect(row)" />
					</td>

					<!-- Data cells -->
					<td
						v-for="col in effectiveColumns"
						:key="col.key"
						:class="[col.class || '', col.cellClass || '', cellClass ? cellClass(row, col) : '']"
						:style="col.width ? { maxWidth: col.width } : {}">
						<slot :name="'column-' + col.key" :row="row" :value="cellValue(row, col)">
							<!-- Every column renders through CnCellRenderer: it resolves
							     col.formatter / col.widget against the injected registries
							     (cnFormatters / cnCellWidgets), uses the schema property when
							     one is available (else {}) for type-aware rendering, and
							     falls back to formatValue(). Columns with `aggregate` get a
							     count of related objects (see cellValue/loadAggregates). The
							     #column-{key} slot still wins. -->
							<CnCellRenderer
								:value="cellValue(row, col)"
								:property="getSchemaProperty(col.key)"
								:formatter="col.formatter || null"
								:widget="col.widget || null"
								:widget-props="col.widgetProps || undefined"
								:row="row"
								:row-key="rowKey" />
						</slot>
					</td>

					<!-- Row actions -->
					<td v-if="$scopedSlots['row-actions']" :class="['cn-table-col--actions', cellClass ? cellClass(row, { key: 'actions' }) : '']" @click.stop>
						<slot name="row-actions" :row="row" />
					</td>
				</tr>
			</tbody>
		</table>
	</div>
</template>

<script>
import { translate as t } from '@nextcloud/l10n'
import { NcLoadingIcon, NcCheckboxRadioSwitch } from '@nextcloud/vue'
import { generateUrl } from '@nextcloud/router'
import axios from '@nextcloud/axios'
import { CnCellRenderer } from '../CnCellRenderer/index.js'
import { columnsFromSchema } from '../../utils/schema.js'

/**
 * CnDataTable — Generic sortable data table for list views.
 *
 * Replaces the copy-pasted `<table class="viewTable">` HTML pattern found in
 * every list view across OpenRegister, Pipelinq, and Procest. Supports sorting,
 * row selection, custom cell rendering via scoped slots, loading states,
 * and empty states.
 *
 * When a `schema` prop is provided, columns are auto-generated from schema
 * properties and cells render through CnCellRenderer for type-aware formatting
 * (dates, booleans, UUIDs, enums, etc.). Scoped slots still override individual
 * columns when needed.
 *
 * Manual columns (backwards compatible)
 * ```vue
 * <CnDataTable
 *   :columns="[
 *     { key: 'name', label: 'Name', sortable: true },
 *     { key: 'email', label: 'Email' },
 *   ]"
 *   :rows="clients"
 *   @row-click="openClient" />
 * ```
 *
 * Schema-driven (auto columns)
 * ```vue
 * <CnDataTable :schema="schema" :rows="objects" />
 * ```
 *
 * Schema with overrides and custom cell
 * ```vue
 * <CnDataTable
 *   :schema="schema"
 *   :exclude-columns="['description']"
 *   :column-overrides="{ status: { width: '200px' } }"
 *   :rows="objects">
 *   <template #column-status="{ row, value }">
 *     <QuickStatusDropdown :case-obj="row" />
 *   </template>
 * </CnDataTable>
 * ```
 */
export default {
	name: 'CnDataTable',

	components: {
		NcLoadingIcon,
		NcCheckboxRadioSwitch,
		CnCellRenderer,
	},

	props: {
		/**
		 * Column definitions (manual mode).
		 * Not required when `schema` is provided.
		 * Each entry may be a full column object OR a bare string key; bare strings
		 * are normalised to `{ key, label }` by `effectiveColumns` so manifest-driven
		 * pages that pass `config.columns` as a string array work without extra mapping.
		 * @type {Array<{key: string, label: string, sortable: boolean, width: string, class: string, cellClass: string}|string>}
		 */
		columns: {
			type: Array,
			default: () => [],
		},
		/**
		 * Schema object with `properties` field (schema-driven mode).
		 * When provided, columns are auto-generated from schema properties.
		 */
		schema: {
			type: Object,
			default: null,
		},
		/** Per-column overrides when using schema mode: { key: { width, label, sortable, ... } } */
		columnOverrides: {
			type: Object,
			default: () => ({}),
		},
		/** Column keys to exclude when using schema mode */
		excludeColumns: {
			type: Array,
			default: () => [],
		},
		/** Column keys to include when using schema mode (whitelist) */
		includeColumns: {
			type: Array,
			default: null,
		},
		/** Row data array. Each row should have a unique identifier (see rowKey). */
		rows: {
			type: Array,
			default: () => [],
		},
		/** Whether data is loading (shows loading spinner) */
		loading: {
			type: Boolean,
			default: false,
		},
		/** Current sort column key */
		sortKey: {
			type: String,
			default: null,
		},
		/** Current sort order: 'asc', 'desc', or null (no sort) */
		sortOrder: {
			type: String,
			default: 'asc',
			validator: (v) => v === null || ['asc', 'desc'].includes(v),
		},
		/** Whether rows can be selected with checkboxes */
		selectable: {
			type: Boolean,
			default: false,
		},
		/** Array of currently selected row IDs */
		selectedIds: {
			type: Array,
			default: () => [],
		},
		/** Property name used as unique row identifier */
		rowKey: {
			type: String,
			default: 'id',
		},
		/** Text shown when there are no rows */
		emptyText: {
			type: String,
			default: () => t('nextcloud-vue', 'No items found'),
		},
		/** Function returning CSS class(es) for a row: (row) => string|object */
		rowClass: {
			type: Function,
			default: null,
		},
		/** Function returning CSS class(es) for a data cell: (row, col) => string|object */
		cellClass: {
			type: Function,
			default: null,
		},
		/** Whether to constrain table height and make it scrollable */
		scrollable: {
			type: Boolean,
			default: false,
		},
		/** Text shown while loading */
		loadingText: {
			type: String,
			default: () => t('nextcloud-vue', 'Loading...'),
		},
	},

	data() {
		return {
			/**
			 * Resolved aggregate-column values, keyed by `String(row[rowKey])`
			 * then by column key. Populated by `loadAggregates()` for columns
			 * that declare `aggregate` (see CnIndexPage's manifest config).
			 *
			 * @type {Object<string, Object<string, number>>}
			 */
			aggregateValues: {},
			/** True while a batch of aggregate-count requests is in flight. */
			aggregateLoading: false,
			/** Monotonic id used to discard a stale aggregate batch when `rows` changes mid-flight. */
			aggregateRequestId: 0,
		}
	},

	computed: {
		/**
		 * Effective columns: schema-generated or manually provided.
		 * Schema columns take precedence when schema is provided and no manual columns given.
		 */
		effectiveColumns() {
			const cols = (this.schema && this.columns.length === 0)
				? columnsFromSchema(this.schema, {
					exclude: this.excludeColumns,
					include: this.includeColumns,
					overrides: this.columnOverrides,
				})
				: this.columns
			return (cols || []).map((c) => (typeof c === 'string' ? { key: c, label: c } : c))
		},

		totalColumns() {
			let count = this.effectiveColumns.length
			if (this.selectable) count++
			if (this.$scopedSlots['row-actions']) count++
			return count
		},

		allSelected() {
			return this.rows.length > 0
				&& this.rows.every((row) => this.selectedIds.includes(row[this.rowKey]))
		},

		someSelected() {
			return this.rows.some((row) => this.selectedIds.includes(row[this.rowKey]))
		},
	},

	watch: {
		rows: {
			handler() { this.loadAggregates() },
		},
		effectiveColumns: {
			handler() { this.loadAggregates() },
			deep: false,
		},
	},

	mounted() {
		this.loadAggregates()
	},

	methods: {
		/**
		 * Get a cell value from a row using dot-notation key.
		 * @param {object} row The row data
		 * @param {string} key The column key (supports dot notation: 'address.city')
		 * @return {*} The cell value
		 */
		getCellValue(row, key) {
			// Guard against columns reaching cellValue without a `.key`
			// (e.g. action / checkbox / row-selector columns, or a
			// malformed column definition). Without this guard,
			// `key.includes('.')` throws TypeError and breaks every
			// row render in the table.
			if (key === undefined || key === null) {
				return undefined
			}
			if (key.includes('.')) {
				return key.split('.').reduce((obj, k) => obj?.[k], row)
			}
			return row[key]
		},

		/**
		 * Get the schema property definition for a column key, or `{}` when
		 * there is no schema (manual mode) or no matching property. The result
		 * is handed to `CnCellRenderer` for type-aware rendering; an empty
		 * object makes it fall back to `formatValue()` (plain truncated text).
		 *
		 * @param {string} key Column key
		 * @return {object} Property definition (possibly empty).
		 */
		getSchemaProperty(key) {
			return this.schema?.properties?.[key] || {}
		},

		/**
		 * Value to render in a cell. For a column that declares `aggregate`
		 * (a count of related objects), returns the cached count once
		 * `loadAggregates()` has resolved it (or `'…'` while pending, `'—'`
		 * if it failed / there's nothing to count). Otherwise the row's
		 * property value via `getCellValue`.
		 *
		 * @param {object} row The row data.
		 * @param {object} col The column definition.
		 * @return {*} The value handed to the slot / CnCellRenderer.
		 */
		cellValue(row, col) {
			if (col && col.aggregate) {
				const cached = this.aggregateValues[String(row[this.rowKey])]
				const v = cached ? cached[col.key] : undefined
				if (v === undefined) return this.aggregateLoading ? '…' : '—'
				return v
			}
			return this.getCellValue(row, col.key)
		},

		/**
		 * Interpolate a column's `aggregate.where` map for one row: any string
		 * value of the form `"@self.<path>"` is replaced with
		 * `getCellValue(row, path)`; everything else is passed through.
		 *
		 * @param {object} where The `aggregate.where` map (may be undefined).
		 * @param {object} row The parent row.
		 * @return {object} The resolved filter map.
		 */
		resolveAggregateWhere(where, row) {
			const out = {}
			for (const [k, v] of Object.entries(where || {})) {
				if (typeof v === 'string' && v.startsWith('@self.')) {
					out[k] = this.getCellValue(row, v.slice('@self.'.length))
				} else {
					out[k] = v
				}
			}
			return out
		},

		/**
		 * For every column that declares `aggregate` (currently `op: "count"`),
		 * issue one `_limit=0` count request per visible row against the related
		 * OpenRegister collection and cache the totals in `aggregateValues`.
		 * Batched with `Promise.all`; a per-request failure degrades that one
		 * cell to `'—'` (logged), never the page. A monotonic request id
		 * discards a stale batch when `rows` / columns change mid-flight.
		 *
		 * @return {Promise<void>}
		 */
		async loadAggregates() {
			const aggCols = this.effectiveColumns.filter((c) => c && c.aggregate && c.aggregate.op === 'count')
			if (aggCols.length === 0) {
				if (Object.keys(this.aggregateValues).length > 0) this.aggregateValues = {}
				this.aggregateLoading = false
				return
			}
			const id = ++this.aggregateRequestId
			this.aggregateLoading = true
			const next = {}
			const jobs = []
			for (const row of this.rows) {
				const rowKey = String(row[this.rowKey])
				next[rowKey] = {}
				for (const col of aggCols) {
					const agg = col.aggregate
					if (!agg.register || !agg.schema) continue
					const where = this.resolveAggregateWhere(agg.where, row)
					jobs.push(
						axios.get(generateUrl(`/apps/openregister/api/objects/${agg.register}/${agg.schema}`), {
							params: { ...where, _limit: 0 },
						})
							.then((res) => {
								const d = res && res.data
								next[rowKey][col.key] = (d && (d.total ?? (Array.isArray(d.results) ? d.results.length : undefined))) ?? 0
							})
							.catch((e) => {
								// eslint-disable-next-line no-console
								console.warn(`[CnDataTable] aggregate "${col.key}" count failed for row ${rowKey}`, e)
								next[rowKey][col.key] = undefined
							}),
					)
				}
			}
			await Promise.all(jobs)
			if (id !== this.aggregateRequestId) return
			this.aggregateValues = next
			this.aggregateLoading = false
		},

		isSelected(row) {
			return this.selectedIds.includes(row[this.rowKey])
		},

		/**
		 * Handle sort column click.
		 * @param {string} key Column key
		 */
		onSort(key) {
			let newKey = key
			let order = 'asc'
			if (this.sortKey === key) {
				if (this.sortOrder === 'asc') {
					order = 'desc'
				} else {
					// desc → disabled: clear sort entirely
					newKey = null
					order = null
				}
			}
			/**
			 * @event sort Emitted when a sortable column header is clicked.
			 * @type {{ key: string|null, order: 'asc'|'desc'|null }}
			 */
			this.$emit('sort', { key: newKey, order })
		},

		toggleSelect(row) {
			const id = row[this.rowKey]
			const newIds = this.isSelected(row)
				? this.selectedIds.filter((i) => i !== id)
				: [...this.selectedIds, id]
			/** @event select Emitted when row selection changes. Payload: array of selected IDs. */
			this.$emit('select', newIds)
		},

		toggleSelectAll() {
			if (this.allSelected) {
				// Remove only current page IDs, preserving cross-page selections
				const currentPageIds = new Set(this.rows.map((row) => row[this.rowKey]))
				this.$emit('select', this.selectedIds.filter((id) => !currentPageIds.has(id)))
			} else {
				// Add current page IDs to existing selections
				const merged = new Set([...this.selectedIds, ...this.rows.map((row) => row[this.rowKey])])
				this.$emit('select', [...merged])
			}
			/** @event select-all Emitted when select-all checkbox is toggled. */
			this.$emit('select-all', !this.allSelected)
		},
	},
}
</script>
